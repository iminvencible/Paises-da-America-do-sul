CREATE DATABASE IF NOT EXISTS america_sul
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE america_sul;

CREATE TABLE IF NOT EXISTS paises (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    capital VARCHAR(120) NOT NULL,
    idioma VARCHAR(120) NOT NULL,
    moeda VARCHAR(120) NOT NULL,
    populacao BIGINT UNSIGNED NULL,
    area_km2 DECIMAL(12,2) NULL,
    presidente VARCHAR(120) NULL,
    idh DECIMAL(4,3) NULL,
    pib_usd DECIMAL(18,2) NULL,
    educacao VARCHAR(120) NULL,
    seguranca VARCHAR(120) NULL,
    saude VARCHAR(120) NULL,
    descricao TEXT NOT NULL,
    bandeira VARCHAR(255) NULL,
    latitude DECIMAL(9,6) NULL,
    longitude DECIMAL(9,6) NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_paises_nome (nome),
    KEY idx_paises_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Carga inicial com os 12 países da América do Sul.
-- Campos sujeitos a mudança (presidente, população, IDH, PIB etc.) podem ser atualizados pelo próprio CRUD.
INSERT IGNORE INTO paises (nome, capital, idioma, moeda, area_km2, presidente, idh, pib_usd, educacao, seguranca, saude, descricao, latitude, longitude)
VALUES
('Argentina', 'Buenos Aires', 'Espanhol', 'Peso argentino', 2780400.00, 'Javier Milei', 0.845, 1100000000000.00, 'Alta', 'Moderada', 'Alta', 'A Argentina é o segundo maior país da América do Sul. Destaca-se pela agricultura, turismo, indústria e produção de alimentos, com grande importância econômica e cultural no continente.', -38.416100, -63.616700),
('Bolívia', 'Sucre (constitucional) / La Paz (sede do governo)', 'Espanhol e idiomas indígenas', 'Boliviano', 1098581.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País andino e amazônico conhecido por sua diversidade cultural, pelo Altiplano e pelo Salar de Uyuni.', -16.290200, -63.588700),
('Brasil', 'Brasília', 'Português', 'Real', 8515767.00, NULL, NULL, NULL, NULL, NULL, NULL, 'Maior país da América do Sul em território, com ampla diversidade ambiental, cultural e econômica.', -14.235000, -51.925300),
('Chile', 'Santiago', 'Espanhol', 'Peso chileno', 756102.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País de formato longitudinal entre a Cordilheira dos Andes e o Oceano Pacífico, com grande variedade de climas.', -35.675100, -71.543000),
('Colômbia', 'Bogotá', 'Espanhol', 'Peso colombiano', 1141748.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País com litoral no Caribe e no Pacífico, reconhecido por sua biodiversidade, regiões andinas e cultura diversa.', 4.570900, -74.297300),
('Equador', 'Quito', 'Espanhol', 'Dólar dos Estados Unidos', 283561.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País atravessado pela linha do Equador, com regiões costeira, andina, amazônica e o arquipélago de Galápagos.', -1.831200, -78.183400),
('Guiana', 'Georgetown', 'Inglês', 'Dólar guianense', 214969.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País do norte da América do Sul, com extensas florestas tropicais e o inglês como idioma oficial.', 4.860400, -58.930200),
('Paraguai', 'Assunção', 'Espanhol e Guarani', 'Guarani', 406752.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País sem litoral no centro-sul do continente, marcado pelo bilinguismo e pela presença dos rios Paraguai e Paraná.', -23.442500, -58.443800),
('Peru', 'Lima', 'Espanhol, Quéchua e Aimará', 'Sol', 1285216.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País de grande patrimônio histórico e arqueológico, com costa do Pacífico, Cordilheira dos Andes e Amazônia.', -9.190000, -75.015200),
('Suriname', 'Paramaribo', 'Neerlandês', 'Dólar surinamês', 163820.00, NULL, NULL, NULL, NULL, NULL, NULL, 'Menor país independente da América do Sul em território, com grande cobertura de floresta tropical.', 3.919300, -56.027800),
('Uruguai', 'Montevidéu', 'Espanhol', 'Peso uruguaio', 176215.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País do Cone Sul conhecido por suas planícies, litoral atlântico e forte concentração urbana em Montevidéu.', -32.522800, -55.765800),
('Venezuela', 'Caracas', 'Espanhol', 'Bolívar', 916445.00, NULL, NULL, NULL, NULL, NULL, NULL, 'País do norte da América do Sul com litoral caribenho, planícies, montanhas e áreas amazônicas.', 6.423800, -66.589700);
