<?php
$title = $title ?? 'Países da América do Sul';
$useLeaflet = $useLeaflet ?? false;
$flashes = pull_flashes();
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Sistema CRUD de países da América do Sul em PHP e MySQL.">
    <title><?= e($title) ?></title>
    <link rel="stylesheet" href="css/estilo.css">
    <?php if ($useLeaflet): ?>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
    <?php endif; ?>
</head>
<body>
<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="index.php" aria-label="Página inicial">
            <span class="brand-mark" aria-hidden="true">🌎</span>
            <span>América do Sul</span>
        </a>
        <?php require dirname(__DIR__) . '/menu.php'; ?>
    </div>
</header>
<main class="container main-content">
    <?php foreach ($flashes as $flash): ?>
        <div class="alert alert-<?= e($flash['type'] ?? 'info') ?>" role="status">
            <?= e($flash['message'] ?? '') ?>
        </div>
    <?php endforeach; ?>
