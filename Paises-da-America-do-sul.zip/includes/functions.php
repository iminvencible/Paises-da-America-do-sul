<?php

declare(strict_types=1);

const MAX_FLAG_SIZE = 2 * 1024 * 1024;
const ALLOWED_FLAG_MIME_TYPES = [
    'image/png' => 'png',
    'image/jpeg' => 'jpg',
    'image/webp' => 'webp',
];

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $location): never
{
    header('Location: ' . $location);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verify_csrf_or_fail(?string $token): void
{
    $stored = $_SESSION['csrf_token'] ?? '';

    if (!is_string($token) || $stored === '' || !hash_equals($stored, $token)) {
        http_response_code(419);
        exit('Sessão expirada ou requisição inválida. Volte à página anterior e tente novamente.');
    }
}

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function pull_flashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);

    return is_array($flashes) ? $flashes : [];
}

function store_form_state(array $data, array $errors = []): void
{
    $_SESSION['form_data'] = $data;
    $_SESSION['form_errors'] = $errors;
}

function pull_form_state(): array
{
    $data = $_SESSION['form_data'] ?? [];
    $errors = $_SESSION['form_errors'] ?? [];
    unset($_SESSION['form_data'], $_SESSION['form_errors']);

    return [
        is_array($data) ? $data : [],
        is_array($errors) ? $errors : [],
    ];
}

function request_id(mixed $value): int
{
    $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

    if ($id === false) {
        http_response_code(400);
        exit('Identificador de país inválido.');
    }

    return (int) $id;
}

function nullable_string(mixed $value): ?string
{
    $value = trim((string) $value);
    return $value === '' ? null : $value;
}

function nullable_int(mixed $value): ?int
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }

    if (!preg_match('/^\d+$/', $value)) {
        return null;
    }

    return (int) $value;
}

function nullable_float(mixed $value): ?float
{
    $value = trim(str_replace(',', '.', (string) $value));
    if ($value === '') {
        return null;
    }

    return is_numeric($value) ? (float) $value : null;
}

function text_length(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function validate_country_input(array $input): array
{
    $data = [
        'nome' => trim((string) ($input['nome'] ?? '')),
        'capital' => trim((string) ($input['capital'] ?? '')),
        'idioma' => trim((string) ($input['idioma'] ?? '')),
        'moeda' => trim((string) ($input['moeda'] ?? '')),
        'populacao' => nullable_int($input['populacao'] ?? ''),
        'area_km2' => nullable_float($input['area_km2'] ?? ''),
        'presidente' => nullable_string($input['presidente'] ?? ''),
        'idh' => nullable_float($input['idh'] ?? ''),
        'pib_usd' => nullable_float($input['pib_usd'] ?? ''),
        'educacao' => nullable_string($input['educacao'] ?? ''),
        'seguranca' => nullable_string($input['seguranca'] ?? ''),
        'saude' => nullable_string($input['saude'] ?? ''),
        'descricao' => trim((string) ($input['descricao'] ?? '')),
        'latitude' => nullable_float($input['latitude'] ?? ''),
        'longitude' => nullable_float($input['longitude'] ?? ''),
    ];

    $errors = [];

    foreach (['nome' => 'Nome do país', 'capital' => 'Capital', 'idioma' => 'Idioma oficial', 'moeda' => 'Moeda', 'descricao' => 'Descrição'] as $field => $label) {
        if ($data[$field] === '') {
            $errors[$field] = $label . ' é obrigatório.';
        }
    }

    foreach (['nome' => 100, 'capital' => 120, 'idioma' => 120, 'moeda' => 120] as $field => $max) {
        if (text_length((string) $data[$field]) > $max) {
            $errors[$field] = 'Máximo de ' . $max . ' caracteres.';
        }
    }

    foreach (['presidente', 'educacao', 'seguranca', 'saude'] as $field) {
        if ($data[$field] !== null && text_length((string) $data[$field]) > 120) {
            $errors[$field] = 'Máximo de 120 caracteres.';
        }
    }

    if (trim((string) ($input['populacao'] ?? '')) !== '' && $data['populacao'] === null) {
        $errors['populacao'] = 'Informe a população com números inteiros, sem separadores.';
    }

    foreach ([
        'area_km2' => 'A área deve ser um número válido.',
        'idh' => 'O IDH deve ser um número válido.',
        'pib_usd' => 'O PIB deve ser um número válido.',
        'latitude' => 'A latitude deve ser um número válido.',
        'longitude' => 'A longitude deve ser um número válido.',
    ] as $field => $message) {
        if (trim((string) ($input[$field] ?? '')) !== '' && $data[$field] === null) {
            $errors[$field] = $message;
        }
    }

    if ($data['area_km2'] !== null && $data['area_km2'] <= 0) {
        $errors['area_km2'] = 'A área deve ser maior que zero.';
    }

    if ($data['idh'] !== null && ($data['idh'] < 0 || $data['idh'] > 1)) {
        $errors['idh'] = 'O IDH deve estar entre 0 e 1.';
    }

    if ($data['pib_usd'] !== null && $data['pib_usd'] < 0) {
        $errors['pib_usd'] = 'O PIB não pode ser negativo.';
    }

    if ($data['latitude'] !== null && ($data['latitude'] < -90 || $data['latitude'] > 90)) {
        $errors['latitude'] = 'Latitude deve estar entre -90 e 90.';
    }

    if ($data['longitude'] !== null && ($data['longitude'] < -180 || $data['longitude'] > 180)) {
        $errors['longitude'] = 'Longitude deve estar entre -180 e 180.';
    }

    return [$data, $errors];
}

function upload_flag(array $file, ?string $currentFilename = null): array
{
    $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);

    if ($error === UPLOAD_ERR_NO_FILE) {
        return [$currentFilename, null, false];
    }

    if ($error !== UPLOAD_ERR_OK) {
        return [$currentFilename, 'Falha no upload da bandeira. Tente novamente.', false];
    }

    $size = (int) ($file['size'] ?? 0);
    if ($size <= 0 || $size > MAX_FLAG_SIZE) {
        return [$currentFilename, 'A bandeira deve ter no máximo 2 MB.', false];
    }

    $tmpName = (string) ($file['tmp_name'] ?? '');
    if ($tmpName === '' || !is_uploaded_file($tmpName)) {
        return [$currentFilename, 'O arquivo enviado não é válido.', false];
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmpName);
    $extension = is_string($mime) ? (ALLOWED_FLAG_MIME_TYPES[$mime] ?? null) : null;

    if ($extension === null || @getimagesize($tmpName) === false) {
        return [$currentFilename, 'Formato inválido. Envie uma imagem PNG, JPG/JPEG ou WEBP.', false];
    }

    $uploadsDir = dirname(__DIR__) . '/uploads';
    if (!is_dir($uploadsDir) && !mkdir($uploadsDir, 0755, true) && !is_dir($uploadsDir)) {
        return [$currentFilename, 'Não foi possível preparar a pasta de uploads.', false];
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $extension;
    $destination = $uploadsDir . '/' . $filename;

    if (!move_uploaded_file($tmpName, $destination)) {
        return [$currentFilename, 'Não foi possível salvar a bandeira enviada.', false];
    }

    return [$filename, null, true];
}

function delete_flag_file(?string $filename): void
{
    if ($filename === null || $filename === '') {
        return;
    }

    $safeName = basename($filename);
    if ($safeName !== $filename) {
        return;
    }

    $path = dirname(__DIR__) . '/uploads/' . $safeName;
    if (is_file($path)) {
        @unlink($path);
    }
}

function format_number_br(int|float|string|null $value, int $decimals = 0): string
{
    if ($value === null || $value === '') {
        return 'Não informado';
    }

    return number_format((float) $value, $decimals, ',', '.');
}

function format_currency_usd(int|float|string|null $value): string
{
    if ($value === null || $value === '') {
        return 'Não informado';
    }

    return 'US$ ' . number_format((float) $value, 2, ',', '.');
}

function display_value(mixed $value): string
{
    if ($value === null || trim((string) $value) === '') {
        return 'Não informado';
    }

    return (string) $value;
}
