<?php
$country = array_merge([
    'nome' => '', 'capital' => '', 'idioma' => '', 'moeda' => '', 'populacao' => '',
    'area_km2' => '', 'presidente' => '', 'idh' => '', 'pib_usd' => '', 'educacao' => '',
    'seguranca' => '', 'saude' => '', 'descricao' => '', 'bandeira' => '', 'latitude' => '', 'longitude' => '',
], $country ?? []);
$errors = $errors ?? [];
$action = $action ?? 'salvar_pais.php';
$submitText = $submitText ?? 'Salvar país';
?>
<form class="country-form" action="<?= e($action) ?>" method="post" enctype="multipart/form-data" novalidate>
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <?php if (!empty($country['id'])): ?>
        <input type="hidden" name="id" value="<?= e($country['id']) ?>">
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">
            Revise os campos destacados antes de continuar.
        </div>
    <?php endif; ?>

    <section class="form-section">
        <h2>Informações principais</h2>
        <div class="form-grid">
            <?php
            $fields = [
                'nome' => ['Nome do país', 'text', 'Ex.: Brasil', true],
                'capital' => ['Capital', 'text', 'Ex.: Brasília', true],
                'idioma' => ['Idioma oficial', 'text', 'Ex.: Português', true],
                'moeda' => ['Moeda', 'text', 'Ex.: Real', true],
                'populacao' => ['População', 'number', 'Ex.: 203000000', false],
                'area_km2' => ['Área territorial (km²)', 'number', 'Ex.: 8515767', false],
                'presidente' => ['Presidente', 'text', 'Nome atual', false],
                'idh' => ['IDH', 'number', 'Ex.: 0.760', false],
                'pib_usd' => ['PIB (US$)', 'number', 'Ex.: 2100000000000', false],
                'educacao' => ['Educação', 'text', 'Ex.: Alta', false],
                'seguranca' => ['Segurança', 'text', 'Ex.: Moderada', false],
                'saude' => ['Saúde', 'text', 'Ex.: Alta', false],
            ];
            foreach ($fields as $name => [$label, $type, $placeholder, $required]):
                $step = in_array($name, ['area_km2', 'idh', 'pib_usd'], true) ? 'any' : '1';
            ?>
                <div class="field <?= isset($errors[$name]) ? 'field-error' : '' ?>">
                    <label for="<?= e($name) ?>"><?= e($label) ?><?= $required ? ' *' : '' ?></label>
                    <input
                        id="<?= e($name) ?>"
                        name="<?= e($name) ?>"
                        type="<?= e($type) ?>"
                        value="<?= e($country[$name] ?? '') ?>"
                        placeholder="<?= e($placeholder) ?>"
                        <?= $required ? 'required' : '' ?>
                        <?= $type === 'number' ? 'step="' . e($step) . '" min="0"' : '' ?>
                        <?= $name === 'idh' ? 'max="1"' : '' ?>
                    >
                    <?php if (isset($errors[$name])): ?><small><?= e($errors[$name]) ?></small><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="form-section">
        <h2>Descrição e localização</h2>
        <div class="field <?= isset($errors['descricao']) ? 'field-error' : '' ?>">
            <label for="descricao">Descrição *</label>
            <textarea id="descricao" name="descricao" rows="6" required placeholder="Resumo sobre o país, cultura, economia, turismo etc."><?= e($country['descricao']) ?></textarea>
            <?php if (isset($errors['descricao'])): ?><small><?= e($errors['descricao']) ?></small><?php endif; ?>
        </div>
        <div class="form-grid two-columns">
            <div class="field <?= isset($errors['latitude']) ? 'field-error' : '' ?>">
                <label for="latitude">Latitude (opcional)</label>
                <input id="latitude" name="latitude" type="number" step="any" min="-90" max="90" value="<?= e($country['latitude']) ?>" placeholder="Ex.: -14.235">
                <?php if (isset($errors['latitude'])): ?><small><?= e($errors['latitude']) ?></small><?php endif; ?>
            </div>
            <div class="field <?= isset($errors['longitude']) ? 'field-error' : '' ?>">
                <label for="longitude">Longitude (opcional)</label>
                <input id="longitude" name="longitude" type="number" step="any" min="-180" max="180" value="<?= e($country['longitude']) ?>" placeholder="Ex.: -51.9253">
                <?php if (isset($errors['longitude'])): ?><small><?= e($errors['longitude']) ?></small><?php endif; ?>
            </div>
        </div>
    </section>

    <section class="form-section">
        <h2>Bandeira</h2>
        <?php if (!empty($country['bandeira'])): ?>
            <div class="current-flag">
                <img src="uploads/<?= e($country['bandeira']) ?>" alt="Bandeira atual de <?= e($country['nome']) ?>">
                <span>Enviar outra imagem substituirá a bandeira atual.</span>
            </div>
        <?php endif; ?>
        <div class="field <?= isset($errors['bandeira']) ? 'field-error' : '' ?>">
            <label for="bandeira">Arquivo da bandeira</label>
            <input id="bandeira" name="bandeira" type="file" accept="image/png,image/jpeg,image/webp">
            <small>PNG, JPG/JPEG ou WEBP, até 2 MB.</small>
            <?php if (isset($errors['bandeira'])): ?><small><?= e($errors['bandeira']) ?></small><?php endif; ?>
        </div>
    </section>

    <div class="form-actions">
        <button class="button button-primary" type="submit"><?= e($submitText) ?></button>
        <a class="button button-secondary" href="listar_paises.php">Cancelar</a>
    </div>
</form>
