</main>
<footer class="site-footer">
    <div class="container">
        <p>Projeto acadêmico • PHP + MySQL + HTML5 + CSS3</p>
    </div>
</footer>
</body>
</html>
