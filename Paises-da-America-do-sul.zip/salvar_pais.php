<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

verify_csrf_or_fail($_POST['csrf_token'] ?? null);
[$data, $errors] = validate_country_input($_POST);

$newFlag = null;
$flagCreated = false;
if (!$errors) {
    [$newFlag, $flagError, $flagCreated] = upload_flag($_FILES['bandeira'] ?? []);
    if ($flagError !== null) {
        $errors['bandeira'] = $flagError;
    }
}

if ($errors) {
    store_form_state($_POST, $errors);
    set_flash('error', 'Não foi possível cadastrar o país. Confira os campos informados.');
    redirect('cadastrar_pais.php');
}

require __DIR__ . '/conexao.php';

$sql = 'INSERT INTO paises
    (nome, capital, idioma, moeda, populacao, area_km2, presidente, idh, pib_usd, educacao, seguranca, saude, descricao, bandeira, latitude, longitude)
    VALUES
    (:nome, :capital, :idioma, :moeda, :populacao, :area_km2, :presidente, :idh, :pib_usd, :educacao, :seguranca, :saude, :descricao, :bandeira, :latitude, :longitude)';

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data + ['bandeira' => $newFlag]);
    set_flash('success', 'País cadastrado com sucesso.');
    redirect('detalhes.php?id=' . (int) $pdo->lastInsertId());
} catch (PDOException $exception) {
    if ($flagCreated) {
        delete_flag_file($newFlag);
    }
    error_log('Erro ao cadastrar país: ' . $exception->getMessage());
    store_form_state($_POST, []);
    $message = $exception->getCode() === '23000'
        ? 'Já existe um país cadastrado com esse nome.'
        : 'Não foi possível salvar o país no banco de dados.';
    set_flash('error', $message);
    redirect('cadastrar_pais.php');
}
