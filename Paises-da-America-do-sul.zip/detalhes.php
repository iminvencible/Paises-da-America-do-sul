<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require __DIR__ . '/conexao.php';

$id = request_id($_GET['id'] ?? null);
$stmt = $pdo->prepare('SELECT * FROM paises WHERE id = :id');
$stmt->execute(['id' => $id]);
$country = $stmt->fetch();

if (!$country) {
    http_response_code(404);
    exit('País não encontrado.');
}

$useLeaflet = $country['latitude'] !== null && $country['longitude'] !== null;
$title = 'Detalhes - ' . $country['nome'];
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading">
    <div><p class="eyebrow">Detalhes do país</p><h1><?= e($country['nome']) ?></h1></div>
    <div class="inline-actions">
        <a class="button button-secondary" href="editar_pais.php?id=<?= $id ?>">Editar</a>
        <form action="excluir_pais.php" method="post" onsubmit="return confirm('Excluir este país permanentemente?');">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= $id ?>">
            <button class="button button-danger" type="submit">Excluir</button>
        </form>
    </div>
</div>

<section class="detail-layout">
    <article class="detail-card">
        <div class="detail-flag">
            <?php if (!empty($country['bandeira'])): ?>
                <img src="uploads/<?= e($country['bandeira']) ?>" alt="Bandeira de <?= e($country['nome']) ?>">
            <?php else: ?>
                <span class="flag-placeholder large" aria-label="Bandeira não enviada">🏳️</span>
            <?php endif; ?>
        </div>
        <div class="detail-data">
            <dl>
                <div><dt>Capital</dt><dd><?= e(display_value($country['capital'])) ?></dd></div>
                <div><dt>Idioma oficial</dt><dd><?= e(display_value($country['idioma'])) ?></dd></div>
                <div><dt>Moeda</dt><dd><?= e(display_value($country['moeda'])) ?></dd></div>
                <div><dt>População</dt><dd><?= e(format_number_br($country['populacao'])) ?></dd></div>
                <div><dt>Área</dt><dd><?= e($country['area_km2'] !== null ? format_number_br($country['area_km2'], 2) . ' km²' : 'Não informado') ?></dd></div>
                <div><dt>Presidente</dt><dd><?= e(display_value($country['presidente'])) ?></dd></div>
                <div><dt>IDH</dt><dd><?= e($country['idh'] !== null ? number_format((float) $country['idh'], 3, ',', '.') : 'Não informado') ?></dd></div>
                <div><dt>PIB</dt><dd><?= e(format_currency_usd($country['pib_usd'])) ?></dd></div>
                <div><dt>Educação</dt><dd><?= e(display_value($country['educacao'])) ?></dd></div>
                <div><dt>Segurança</dt><dd><?= e(display_value($country['seguranca'])) ?></dd></div>
                <div><dt>Saúde</dt><dd><?= e(display_value($country['saude'])) ?></dd></div>
            </dl>
        </div>
    </article>

    <article class="description-card">
        <h2>Descrição</h2>
        <p><?= nl2br(e($country['descricao'])) ?></p>
    </article>
</section>

<?php if ($useLeaflet): ?>
    <section class="map-card">
        <h2>Localização no mapa</h2>
        <div id="map" aria-label="Mapa de <?= e($country['nome']) ?>"></div>
    </section>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script>
        const map = L.map('map').setView([<?= json_encode((float) $country['latitude']) ?>, <?= json_encode((float) $country['longitude']) ?>], 4);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
        L.marker([<?= json_encode((float) $country['latitude']) ?>, <?= json_encode((float) $country['longitude']) ?>])
            .addTo(map)
            .bindPopup(<?= json_encode($country['nome'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>)
            .openPopup();
    </script>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
