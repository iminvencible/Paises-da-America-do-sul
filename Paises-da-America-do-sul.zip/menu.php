<nav class="main-nav" aria-label="Navegação principal">
    <a href="index.php">Início</a>
    <a href="listar_paises.php">Países cadastrados</a>
    <a href="cadastrar_pais.php">Cadastrar país</a>
</nav>
