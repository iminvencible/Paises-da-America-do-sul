<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

verify_csrf_or_fail($_POST['csrf_token'] ?? null);
$id = request_id($_POST['id'] ?? null);
require __DIR__ . '/conexao.php';

$stmt = $pdo->prepare('SELECT * FROM paises WHERE id = :id');
$stmt->execute(['id' => $id]);
$current = $stmt->fetch();
if (!$current) {
    http_response_code(404);
    exit('País não encontrado.');
}

[$data, $errors] = validate_country_input($_POST);
$newFlag = $current['bandeira'];
$flagCreated = false;

if (!$errors) {
    [$newFlag, $flagError, $flagCreated] = upload_flag($_FILES['bandeira'] ?? [], $current['bandeira']);
    if ($flagError !== null) {
        $errors['bandeira'] = $flagError;
    }
}

if ($errors) {
    store_form_state($_POST, $errors);
    set_flash('error', 'Não foi possível atualizar o país. Confira os campos informados.');
    redirect('editar_pais.php?id=' . $id);
}

$sql = 'UPDATE paises SET
    nome = :nome, capital = :capital, idioma = :idioma, moeda = :moeda, populacao = :populacao,
    area_km2 = :area_km2, presidente = :presidente, idh = :idh, pib_usd = :pib_usd,
    educacao = :educacao, seguranca = :seguranca, saude = :saude, descricao = :descricao,
    bandeira = :bandeira, latitude = :latitude, longitude = :longitude
    WHERE id = :id';

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data + ['bandeira' => $newFlag, 'id' => $id]);

    if ($flagCreated && !empty($current['bandeira']) && $current['bandeira'] !== $newFlag) {
        delete_flag_file($current['bandeira']);
    }

    set_flash('success', 'Dados atualizados com sucesso.');
    redirect('detalhes.php?id=' . $id);
} catch (PDOException $exception) {
    if ($flagCreated && $newFlag !== $current['bandeira']) {
        delete_flag_file($newFlag);
    }
    error_log('Erro ao atualizar país: ' . $exception->getMessage());
    store_form_state($_POST, []);
    $message = $exception->getCode() === '23000'
        ? 'Já existe outro país cadastrado com esse nome.'
        : 'Não foi possível atualizar os dados no banco.';
    set_flash('error', $message);
    redirect('editar_pais.php?id=' . $id);
}
