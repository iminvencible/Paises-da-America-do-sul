<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Método não permitido.');
}

verify_csrf_or_fail($_POST['csrf_token'] ?? null);
$id = request_id($_POST['id'] ?? null);
require __DIR__ . '/conexao.php';

$stmt = $pdo->prepare('SELECT nome, bandeira FROM paises WHERE id = :id');
$stmt->execute(['id' => $id]);
$country = $stmt->fetch();

if (!$country) {
    set_flash('error', 'O país informado não existe mais.');
    redirect('listar_paises.php');
}

try {
    $stmt = $pdo->prepare('DELETE FROM paises WHERE id = :id');
    $stmt->execute(['id' => $id]);
    delete_flag_file($country['bandeira']);
    set_flash('success', 'País excluído com sucesso.');
} catch (PDOException $exception) {
    error_log('Erro ao excluir país: ' . $exception->getMessage());
    set_flash('error', 'Não foi possível excluir o país.');
}

redirect('listar_paises.php');
