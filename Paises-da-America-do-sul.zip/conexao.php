<?php

declare(strict_types=1);

$host = getenv('DB_HOST') ?: '127.0.0.1';
$port = getenv('DB_PORT') ?: '3306';
$dbName = getenv('DB_NAME') ?: 'america_sul';
$dbUser = getenv('DB_USER') ?: 'root';
$dbPassEnv = getenv('DB_PASS');
$dbPass = $dbPassEnv === false ? '' : $dbPassEnv;

$dsn = "mysql:host={$host};port={$port};dbname={$dbName};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $exception) {
    error_log('Falha de conexão com o banco: ' . $exception->getMessage());
    http_response_code(500);
    exit('Não foi possível conectar ao banco de dados. Verifique se o MySQL está iniciado e se o banco america_sul foi importado.');
}
