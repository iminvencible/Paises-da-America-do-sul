<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

$failures = [];

function check(bool $condition, string $message): void
{
    global $failures;
    if (!$condition) {
        $failures[] = $message;
    }
}

[$valid, $errors] = validate_country_input([
    'nome' => 'Brasil',
    'capital' => 'Brasília',
    'idioma' => 'Português',
    'moeda' => 'Real',
    'populacao' => '203000000',
    'area_km2' => '8515767',
    'idh' => '0.760',
    'pib_usd' => '2100000000000',
    'descricao' => 'Descrição de teste',
    'latitude' => '-14.235',
    'longitude' => '-51.9253',
]);
check($errors === [], 'Dados válidos não devem gerar erros.');
check($valid['populacao'] === 203000000, 'População deve ser convertida em inteiro.');
check(abs((float) $valid['idh'] - 0.760) < 0.0001, 'IDH deve ser convertido em número.');

[, $errors] = validate_country_input([
    'nome' => '',
    'capital' => '',
    'idioma' => '',
    'moeda' => '',
    'descricao' => '',
    'idh' => '1.5',
    'latitude' => '-91',
    'longitude' => '181',
    'area_km2' => 'abc',
]);
check(isset($errors['nome']), 'Nome vazio deve ser rejeitado.');
check(isset($errors['idh']), 'IDH acima de 1 deve ser rejeitado.');
check(isset($errors['latitude']), 'Latitude fora do intervalo deve ser rejeitada.');
check(isset($errors['longitude']), 'Longitude fora do intervalo deve ser rejeitada.');
check(isset($errors['area_km2']), 'Área não numérica deve ser rejeitada.');

check(e('<script>') === '&lt;script&gt;', 'Saída HTML deve ser escapada.');
check(display_value(null) === 'Não informado', 'Valor nulo deve ter fallback amigável.');

if ($failures) {
    fwrite(STDERR, "Falhas:\n- " . implode("\n- ", $failures) . "\n");
    exit(1);
}

echo "OK: testes de funções passaram.\n";
