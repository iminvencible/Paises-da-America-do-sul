<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';

$title = 'Países da América do Sul';
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
    <div class="hero-copy">
        <p class="eyebrow">Sistema de Desenvolvimento de Sistemas</p>
        <h1>Países da América do Sul</h1>
        <p>Cadastre, consulte, edite e exclua informações dos países, com dados armazenados em MySQL e upload seguro da bandeira.</p>
        <div class="hero-actions">
            <a class="button button-primary button-large" href="listar_paises.php">Países cadastrados</a>
            <a class="button button-secondary button-large" href="cadastrar_pais.php">Cadastrar país</a>
        </div>
    </div>
    <div class="hero-card" aria-label="Resumo das funcionalidades">
        <span class="hero-icon" aria-hidden="true">🗺️</span>
        <h2>CRUD completo</h2>
        <p>Cadastro, consulta, detalhes, edição, exclusão, pesquisa, ordenação, estatísticas, upload de imagens e mapa.</p>
    </div>
</section>

<section class="feature-grid" aria-label="Funcionalidades do sistema">
    <article class="feature-card"><span aria-hidden="true">➕</span><h2>Cadastro</h2><p>Formulário completo para registrar os dados de cada país.</p></article>
    <article class="feature-card"><span aria-hidden="true">🔎</span><h2>Consulta</h2><p>Pesquisa pelo nome e ordenação alfabética.</p></article>
    <article class="feature-card"><span aria-hidden="true">✏️</span><h2>Edição</h2><p>Atualize dados e substitua a bandeira quando necessário.</p></article>
    <article class="feature-card"><span aria-hidden="true">📍</span><h2>Mapa</h2><p>Visualize a localização do país quando houver coordenadas cadastradas.</p></article>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
