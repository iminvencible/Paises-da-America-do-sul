# Exercícios sugeridos

1. Torne a bandeira obrigatória somente no primeiro cadastro.
2. Adicione um filtro por idioma oficial.
3. Crie uma ordenação por área territorial.
4. Mostre no início quantos países já têm bandeira cadastrada.
5. Adicione paginação à listagem.
6. Crie uma confirmação visual antes de excluir sem usar `confirm()` do navegador.
7. Adicione testes de integração usando um banco de dados exclusivo para testes.
8. Implemente autenticação para que somente usuários autorizados possam editar e excluir.
