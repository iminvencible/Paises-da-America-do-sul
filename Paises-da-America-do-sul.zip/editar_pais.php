<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require __DIR__ . '/conexao.php';

$id = request_id($_GET['id'] ?? null);
$stmt = $pdo->prepare('SELECT * FROM paises WHERE id = :id');
$stmt->execute(['id' => $id]);
$country = $stmt->fetch();

if (!$country) {
    http_response_code(404);
    exit('País não encontrado.');
}

[$formData, $errors] = pull_form_state();
if ($formData) {
    $country = array_merge($country, $formData);
    $country['id'] = $id;
}

$title = 'Editar - ' . $country['nome'];
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading">
    <div><p class="eyebrow">Alteração de dados</p><h1>Editar <?= e($country['nome']) ?></h1></div>
    <a class="button button-secondary" href="detalhes.php?id=<?= $id ?>">Voltar aos detalhes</a>
</div>
<?php
$action = 'atualizar_pais.php';
$submitText = 'Salvar alterações';
require __DIR__ . '/includes/form_pais.php';
require __DIR__ . '/includes/footer.php';
?>
