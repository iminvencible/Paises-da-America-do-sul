<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';
require __DIR__ . '/conexao.php';

$q = trim((string) ($_GET['q'] ?? ''));
$order = strtolower((string) ($_GET['ordem'] ?? 'asc'));
$order = in_array($order, ['asc', 'desc'], true) ? $order : 'asc';
$orderSql = $order === 'desc' ? 'DESC' : 'ASC';

$params = [];
$where = '';
if ($q !== '') {
    $where = 'WHERE nome LIKE :q';
    $params['q'] = '%' . $q . '%';
}

$stmt = $pdo->prepare("SELECT id, nome, capital, idioma, moeda, bandeira FROM paises {$where} ORDER BY nome {$orderSql}");
$stmt->execute($params);
$countries = $stmt->fetchAll();

$total = (int) $pdo->query('SELECT COUNT(*) FROM paises')->fetchColumn();

$title = 'Países cadastrados';
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading">
    <div>
        <p class="eyebrow">Consulta</p>
        <h1>Países cadastrados</h1>
        <p class="muted">Total no banco: <strong><?= $total ?></strong></p>
    </div>
    <a class="button button-primary" href="cadastrar_pais.php">+ Cadastrar país</a>
</div>

<form class="toolbar" method="get" action="listar_paises.php">
    <div class="search-field">
        <label class="sr-only" for="q">Buscar país pelo nome</label>
        <input id="q" name="q" type="search" value="<?= e($q) ?>" placeholder="Buscar país pelo nome...">
    </div>
    <label for="ordem">Ordenar:</label>
    <select id="ordem" name="ordem">
        <option value="asc" <?= $order === 'asc' ? 'selected' : '' ?>>A → Z</option>
        <option value="desc" <?= $order === 'desc' ? 'selected' : '' ?>>Z → A</option>
    </select>
    <button class="button button-secondary" type="submit">Aplicar</button>
    <?php if ($q !== ''): ?><a class="text-link" href="listar_paises.php">Limpar</a><?php endif; ?>
</form>

<?php if (!$countries): ?>
    <section class="empty-state">
        <span aria-hidden="true">🌎</span>
        <h2>Nenhum país encontrado</h2>
        <p><?= $q !== '' ? 'Tente outro termo de pesquisa.' : 'Cadastre o primeiro país para começar.' ?></p>
        <a class="button button-primary" href="cadastrar_pais.php">Cadastrar país</a>
    </section>
<?php else: ?>
    <section class="country-grid">
        <?php foreach ($countries as $country): ?>
            <article class="country-card">
                <div class="flag-frame">
                    <?php if (!empty($country['bandeira'])): ?>
                        <img src="uploads/<?= e($country['bandeira']) ?>" alt="Bandeira de <?= e($country['nome']) ?>" loading="lazy">
                    <?php else: ?>
                        <span class="flag-placeholder" aria-label="Bandeira não enviada">🏳️</span>
                    <?php endif; ?>
                </div>
                <div class="country-card-body">
                    <h2><?= e($country['nome']) ?></h2>
                    <p><strong>Capital:</strong> <?= e(display_value($country['capital'])) ?></p>
                    <p><strong>Idioma:</strong> <?= e(display_value($country['idioma'])) ?></p>
                    <p><strong>Moeda:</strong> <?= e(display_value($country['moeda'])) ?></p>
                    <a class="button button-secondary button-block" href="detalhes.php?id=<?= (int) $country['id'] ?>">Ver detalhes</a>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
