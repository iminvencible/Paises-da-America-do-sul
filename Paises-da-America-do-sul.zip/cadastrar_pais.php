<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/init.php';

[$country, $errors] = pull_form_state();
$title = 'Cadastrar país';
require __DIR__ . '/includes/header.php';
?>
<div class="page-heading">
    <div><p class="eyebrow">Novo registro</p><h1>Cadastrar país</h1></div>
    <a class="button button-secondary" href="listar_paises.php">Ver países</a>
</div>
<?php
$action = 'salvar_pais.php';
$submitText = 'Cadastrar país';
require __DIR__ . '/includes/form_pais.php';
require __DIR__ . '/includes/footer.php';
?>
